#Author: Sumit.Bhanse@ril.com
echo -e "Enter the absolute path of you hostfile"
read hostfile
cat $hostfile | grep -i worker >/dev/null
if [[ $? -eq 0 ]];then
  echo "delete older data from "$hostfile" 1st"
else
 echo "enter option to choose region"
 echo "North:   1"
 echo "South:   2"
 echo "East:    3"
 echo "West:    4"
 echo "Central: 5"

 read manager
 echo -e "enter worker user \n"
 read  workeruser
 echo -e "enter password \n(password will be readed silently)"
 read -s pass
 sed -i '1i [workers]' $hostfile
 sed -i '$ a [workers:vars]' $hostfile
 sed -i "$ a ansible_ssh_user=${workeruser}" $hostfile
 sed -i "$ a ansible_ssh_pass=${pass}" $hostfile

 sed -i '$ a [DSA]' $hostfile
 sed -i '$ a 2405:200:5518:0:3496::12  ansible_ssh_user=healthcheck ansible_ssh_pass=k&b04kC^Q9(d' $hostfile
 sed -i '$ a 2405:200:5518:0:3496::16  ansible_ssh_user=healthcheck ansible_ssh_pass=k&b04kC^Q9(d' $hostfile
 sed -i '$ a [repo]' $hostfile
 sed -i '$ a 2405:200:5501:2:3902:0:66:2 ansible_ssh_user=healthcheck ansible_ssh_pass=k&b04kC^Q9(d' $hostfile
 sed -i '$ a [manager]' $hostfile
 if [[ $manager == '3' ]];then
   {
    sed -i '$ a 2405:200:5518:0:3497::10 ansible_ssh_user=healthcheck ansible_ssh_pass=k&b04kC^Q9(d' $hostfile
   }
 elif [[ $manager == '4' ]];then
   {
    sed -i '$ a 2405:200:5518:0:3497::4 ansible_ssh_user=healthcheck ansible_ssh_pass=k&b04kC^Q9(d' $hostfile
   }
 elif [[ $manager == '1' ]];then
   {
    sed -i '$ a 2405:200:5518:0:3497::16 ansible_ssh_user=healthcheck ansible_ssh_pass=k&b04kC^Q9(d' $hostfile
   }
 elif [[ $manager == '2' ]];then
   {
    sed -i '$ a 2405:200:5518:0:3497::8 ansible_ssh_user=healthcheck ansible_ssh_pass=k&b04kC^Q9(d' $hostfile
   }
 elif [[ $manager == '5' ]];then
   {
    sed -i '$ a 2405:200:5518:0:3497::13 ansible_ssh_user=healthcheck ansible_ssh_pass=k&b04kC^Q9(d' $hostfile
   }
 else
 {
  :
 }
 fi

  echo "How many cvims are there"
  read cvimCount
  cvimString=''
  for (( i=1; i<=$cvimCount; i++ ))
  do
   echo "enter CVIM name(entry $i)"
   read cvimName
  #cvimList+=($cvimName)
   cvimString="${cvimString},'$cvimName'"
  done
  #echo $cvimString
  cvimString=cvimname=[${cvimString}]
  echo "[all:vars]" >> $hostfile
  echo "$cvimString" | sed "s/,]/]/g" | sed "s/\[,/[/" >> $hostfile
 #Email id data
 echo -e "Enter the email ids [press enter to skip;support multiple email-ids with "," seperated ]"
 read email_id
 for id in ${email_id//,/ }; do
    CURL_ARGS+=(--mail-rcpt "$id")
 done 
 #echo "!!!Kindly run below command to check end to end reachability!!!"
 #echo -e "\n"
 read -p  "Do you want to save the output in file(y/n): " yn
 case $yn in
 [yY]* ) read -p "enter output file name: " outputFile && sudo ansible-playbook -i $hostfile reach-telnet.yml -f150 | tee ${PWD}/output/$outputFile; echo "output has been saved on the path '${PWD}/output/$outputFile'" ;;
 [nN]* ) ansible-playbook -i $hostfile reach-telnet.yml -f150;;
 [[cC]]* ) echo -e "hostfile $hostfile has been created you can run 'sudo ansible-playbook -i $hostfile reach-telnet.yml'" ;;
 * ) exit ;;
 esac
 #echo "ansible-playbook -i $hostfile reach-telnet.yml"
 if [[ -n "${email_id}" ]];then
   (echo "From: Jio5GHealthNotifications@ril.com"; \
    echo "To: ${email_id}"; \
    echo "Subject: E2E reachability of ${outputFile}"; \
    echo "MIME-Version: 1.0"; \
    echo "Content-Type: multipart/mixed; boundary=BOUNDARY"; \
    echo; \
    echo "--BOUNDARY"; \
    echo "Content-Type: text/plain"; \
    echo; \
    echo "Dear user please find the attached reachability output file: ${outputFile}."; \
    echo "--BOUNDARY"; \
    echo "Content-Type: application/zip; name=\"${outputFile}\""; \
    echo "Content-Transfer-Encoding: base64"; \
    echo "Content-Disposition: attachment; filename=\"${outputFile}\""; \
    echo; \
    base64 output/${outputFile}; \
    echo "--BOUNDARY--") \
    | curl --url "smtp://a2smtp.ipv6.bss.jio.com:25" \
           --ssl \
           --mail-from "Jio5GHealthNotifications@ril.com" \
           "${CURL_ARGS[@]}" \
           --upload-file -
   echo "mail sent"
 else
   echo "mail step skipped"
 fi

fi
